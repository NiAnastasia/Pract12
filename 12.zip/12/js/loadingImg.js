let dropBox = $(".drop-area");

$(function() {
  dropBox.on("dragover", prevent);
  dropBox.on("dragenter", prevent);
  dropBox.on("drop", drop);
});

let drop = function(el) {
  prevent(el);
  const { files } = el.originalEvent.dataTransfer;
  processingFiles(files);
};

let prevent = function(el) {
  el.preventDefault();
  el.stopPropagation();
};

let processingFiles = function(files) {
  let file = files[0],
  validFile = "png";
  console.log(file.name.split('.').pop());

  if (file.type.slice(0, 5) == "image") {
    if (file.name.split('.').pop() != validFile) {
      alert("Image no png");
      return 0;
    }
    let img = $("<img>"),
    reader = new FileReader();

    reader.readAsDataURL(file);

    reader.onloadend = function() {
      img.attr("src", reader.result);
    };

    $("body").append(img);
    let imgData = $("body img").last();
    imgData.load(function() {
      imgData.remove();
      figure.children().remove();
      figure.append(img);
      startSettings();
      }
    );
  } 
};
