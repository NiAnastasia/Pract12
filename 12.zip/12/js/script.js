let i = 10,
listSticker = $("menu ul:not(:first-child)"),
stickerClone,
innerStickers,
stickerSize = { width: "0", height: "0" },
heightPlus = $("input[name='height-plus']"),
heightMinus = $("input[name='height-minus']"),
widthPlus = $("input[name='width-plus']"),
widthMinus = $("input[name='width-minus']"),
printButton = $("input[name='print']"),
figure = $("figure"),
elemClone,
checkDrop,
stickerButton = $("input[name='sticker']"),
spoilerButton = $("input[name='spoiler']"),
rimsButton = $("input[name='rims']");



$("ul:nth-of-type(3)").css("display", "none");
$("ul:nth-of-type(4)").css("display", "none");
figure.css("position", "relative");
$("menu").css("z-index", "102");


stickerButton.click(function() {
  $("ul:nth-of-type(2)").css("display", "block");
  $("ul:nth-of-type(3)").css("display", "none");
  $("ul:nth-of-type(4)").css("display", "none");
})

spoilerButton.click(function() {
  $("ul:nth-of-type(2)").css("display", "none");
  $("ul:nth-of-type(3)").css("display", "block");
  $("ul:nth-of-type(4)").css("display", "none");
})

rimsButton.click(function() {
  $("ul:nth-of-type(2)").css("display", "none");
  $("ul:nth-of-type(3)").css("display", "none");
  $("ul:nth-of-type(4)").css("display", "block");
})


printButton.click(function() {
  $("figure").load(window.print());
});


listSticker.find("img").draggable({
  scope: "firstStickers",
  helper: "clone",
  start: function(event, ui) {
    
    stickerSize.width = getSize(this).width;
    stickerSize.height = getSize(this).height;
    ui.helper.css({
      width: stickerSize.width,
      height: stickerSize.height,
      "z-index": "99"
    });
    elemClone = $(this);
    elemClone.css("display", "none");
    checkDrop = false;
  },
  stop: function() {
    if (!checkDrop){
    elemClone.css("display", "inline");
    }
  }
});

figure.droppable({
  scope: "firstStickers",
  tolerance: "fit",
  drop: function(event, ui) {
    checkDrop = true;
    elemClone.css("display", "none");
    stickerClone = ui.helper.clone();
    $(this).prepend(stickerClone);
    stickerClone.css({
      position: "absolute",
      top: getCoord(ui.helper[0]).top - getCoord(this).top,
      left: getCoord(ui.helper[0]).left - getCoord(this).left,
      "z-index": i++
    });

    figure.find("img:not(:last-child)").click(function(event) {
      innerStickers = $(this.parentNode).find("img:not(:last-child)");
      innerStickers.draggable({
         disabled: true 
        });
      innerStickers.css("border", "");
      $(event.target).css({
        border: "1px solid red"
      });
      $(event.target).draggable({
        disabled: false,
      });

      $("body").on("keydown", function(e) {});

      heightPlus.on("click", function() {
        $(event.target).css({
          height: getSize(event.target).height + 5
        });
      });

      heightMinus.on("click", function() {
        $(event.target).css({
          height: getSize(event.target).height - 5
        });
      });

      widthMinus.on("click", function() {
        $(event.target).css({
          width: getSize(event.target).width - 5
        });
      });

      widthPlus.on("click", function() {
        $(event.target).css({
          width: getSize(event.target).width + 5
        });
      });
    });
  }
});

function getSize(element) {
  let width = element.clientWidth,
  height = element.clientHeight;
  return {width: width, height: height};
}

function getCoord(element) {
  let top = element.getBoundingClientRect().top,
  bottom = element.getBoundingClientRect().bottom,
  right = element.getBoundingClientRect().right,
  left = element.getBoundingClientRect().left;
  return {top: top, bottom: bottom, right: right, left: left, preventTop: 0, preventLeft: 0};
}
